from testing import ImAClass




obj = ImAClass(1)


obj.run()